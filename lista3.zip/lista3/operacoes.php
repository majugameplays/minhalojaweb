<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Exercicio 4</title>
    </head>
    <body>

         <form action="resultadooperacoes.php" method="POST">
            Número 1: <input type ="text" name="numero1"><br>
            <BR>
            Número 2: <input type ="text" name="numero2"><br>
            <br>
            
             <input type="radio" name="op" value="som">  Soma
             <input type="radio" name="op" value="sub">  Subtração
             <input type="radio" name="op" value="div">  Divisão
             <input type="radio" name="op" value="mult">  Multiplicação
             <br><br>
            <button type="submit">Enviar</button> 
            
        </form>
        
        
        
    </body>
</html>