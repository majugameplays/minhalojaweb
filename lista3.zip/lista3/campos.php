<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <form action="processa.php" method="POST">
            Número 1: <input type="text" name="n1"><br><br>
            Número 2: <input type="text" name="n2"><br><br>
            Número 3: <input type="text" name="n3"><br><br>
            Número 4: <input type="text" name="n4"><br><br>
            Número 5: <input type="text" name="n5"><br><br>
            <button type="submit" value="enviar">Enviar</button>
            
                
        </form>
    </body>
</html>