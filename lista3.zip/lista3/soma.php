<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Exercicio 1</title>
    </head>
    <body>
        <form action="resultado.php" method="POST">
            Número 1: <input type ="text" name="numero1"><br>
            <BR>
            Número 2: <input type ="text" name="numero2"><br>
            <br>
            <button type="submit">Somar</button>
            
        </form>
    </body>
</html>